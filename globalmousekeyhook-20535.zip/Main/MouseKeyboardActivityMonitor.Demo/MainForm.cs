﻿using System.Windows.Forms;

namespace MouseKeyboardActivityMonitor.Demo
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
    }
}
