﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Gma.GlobalHookDemo")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("George Mamaladze")]
[assembly: AssemblyProduct("Gma.GlobalHookDemo")]
[assembly: AssemblyCopyright("Open Source under Microsoft Public License (Ms-PL)")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("f2132841-0c18-4146-af75-a30b73dffe0f")]
[assembly: AssemblyVersion("4.0.0.*")]
