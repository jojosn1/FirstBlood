using System.Reflection;

[assembly: AssemblyTitle("MouseKeyboardActivityMonitor")]
[assembly: AssemblyDescription("This class library contains components to monitor mouse and keyboard activities and provides appropriate events.")]
[assembly: AssemblyCompany("Mouse and Keyboard Hooks .NET")]
[assembly: AssemblyProduct("Mouse and Keyboard Hooks .NET")]
[assembly: AssemblyCopyright("Open Source under Ms-PL License.")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("4.0.0.*")]